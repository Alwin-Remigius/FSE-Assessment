package com.cognizant.projectmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMangementFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMangementFinalApplication.class, args);
	}
}
